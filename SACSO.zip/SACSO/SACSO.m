%%%*********************************************************************************************************%%%
%% Implementation of surrogate-assisted competitive swarm optimizer (SACSO)
%% Pan J S, Liang Q, Chu S C, et al. A multi-strategy surrogate-assisted competitive swarm 
%% optimizer for expensive optimization problems[J]. Applied Soft Computing, 2023: 110733.
%% Author: Qingwei Liang
%% Email:  liangqw@sdust.edu.cn

clear,clc
rng('default');
rng('shuffle');
warning('off');
D=30; %dimension of problem
fname='FITNESS'; % benchmark function
sn1=1;
runnum=20;
if D <= 30
    fun_nums=5;
    problem_namearr={'Ellipsoid','Rosenbrock','Ackley','Griewank','Rastrigin'};
    buarr=[5.12,2.048,32.768,600,5.12];
    bdarr=[-5.12,-2.048,-32.768,-600,-5.12];
    maxfe=500; % Maximum number of evaluations
else
    fun_nums=6;
    problem_namearr={'Ellipsoid','Rosenbrock','Ackley','Griewank','CECF10','CECF19'};
    buarr=[5.12,2.048,32.768,600,5,5];
    bdarr=[-5.12,-2.048,-32.768,-600,-5,-5];
    maxfe=1000;
end

for ifun=1:1
    problem_name=char(problem_namearr(ifun));
    gfs=zeros(1,fix(maxfe/sn1));
    CE=zeros(maxfe,2);
    gsamp1=[];
    for run=1:1
        %run
        fprintf('ifun: %d run: %d \n', ifun, run);
        %---------------Initialization-----------------
        %population size
        if D <= 20       
            ps= 5*d;
        else
            ps= 100;
        end
        v = zeros(ps, D);  
        %parameter
        m=0.4*ps;c=0.75;
        %variable_domain
        Xmax = buarr(ifun);
        Xmin = bdarr(ifun);
        Rmin = repmat(Xmin,1,D);
        Rmax = repmat(Xmax,1,D);
        VRmin = repmat(Rmin,ps,1);
        VRmax = repmat(Rmax,ps,1);
        FES = 0;    gen = 0;    
        
        %population initialization
        p = VRmin + (VRmax - VRmin) .* lhsdesign(ps, D);     
        fitness=zeros(1,ps);
        for ii=1:ps
            fitness(ii) = compute_objectives(p(ii,:),D,problem_name); % feval(fname,p(ii,:));% feval(fname,p(ii,:));
            FES=FES+1;
            if FES <= maxfe 
                CE(FES,:)=[FES,fitness(ii)];
                if mod (FES,sn1)==0
                    cs1=FES/sn1;
                    gfs(1,cs1)=min(CE(1:FES,2));
                end
            end
        end  
        
        % Global search 1
        center = mean(p);
        [k,pastid]=ismember(center,p,'rows');
        if k<1
            sbest_pos=center;
            sbesty=compute_objectives(sbest_pos,D,problem_name); 
            CE(FES,:)=[FES,sbesty];
            if mod (FES,sn1)==0
                cs1=FES/sn1;
                gfs(1,cs1)=min(CE(1:FES,2));
            end
            p=[p;sbest_pos];   fitness=[fitness,sbesty];
        end
        
        hx=p;   hf=fitness; %Database                                     
        [bestever,id] = min(fitness);
        gbpos=p(id,:); 
        [~,idx]=sort(hf);   idx=idx(1:ps);
        p=hx(idx,:);        fitness=hf(idx);  
        
        pbest = p;
        pbestval = fitness;
        [gbestval,gbestid] = min(pbestval);
        gbest = pbest(gbestid,:);
        gbestrep= repmat(gbest,ps,1);
        
        
        %%
        num_gen=30;% number of iterations of CSO
        noupdate=0;
        global1=0;global2=0;
        gbestval_old= gbestval;
        globalsearch = 1;
        localsearch=0;
        reversesearch=0;
        updatemodel=1;
        firstupdate=1;
        globalcount=0;
        localcount=0;
        globalcountsuc=0;
        localcountsuc=0;
        reversecount=0;
        reversecountsuc=0;
        while(FES < maxfe)
           %% Part 1: Particle selection criteria
            if mod(gen, num_gen) == 0 && gen>1
                updatemodel=1;
                fprintf('Iteration: %d Fitness evaluation: %d Best fitness: %e\n', gen, FES, bestever);
                
                if(reversesearch == 1) %Opposition-based search 
                    [~,idx]=sort(fitness); 
                    p_app=p(idx,:); f_app=fitness(idx);
                    [~,~,ip]=intersect(hx,p_app,'rows');
                    p_app(ip,:)=[];
                    f_app(ip)=[];
                    if ~isempty(p_app)==1
                        [mmin,id_min]=min(fitness);
                        [mmax,id_max]=max(fitness);
                        sbest_pos=(p(id_min,:)+p(id_max,:))*rand-p_app(1,:);
                        for j=1:D
                            [mmin,i_min]=min(p(:,j));
                            [mmax,i_max]=max(p(:,j));
                            r_list=randperm(ps);
                            r_list=r_list(1:m);
                            r=rand;
                            for i=1:m
                                if (r_list(i)~=id_min)
                                    p(r_list(i),j)=(p(i_min,j)+p(i_max,j))*r-p_app(1,j);
                                end
                            end
                        end
                        sbesty=compute_objectives(sbest_pos,D,problem_name);
                        FES=FES+1;
                        CE(FES,:)=[FES,sbesty];
                        if mod (FES,sn1)==0
                            cs1=FES/sn1;
                            gfs(1,cs1)=min(CE(1:FES,2));
                        end
                        hx=[hx;sbest_pos];   hf=[hf,sbesty];
                        if sbesty<bestever
                            gbpos=sbest_pos; 
                            reversecountsuc=reversecountsuc+1;   
                        end
                        [bestever,ib] = min([sbesty, bestever]); 
                    end
                end
                 
                if(globalsearch == 1) % Global search 2
                    gauss=normrnd(0,1,1);
                    lamda=FES/maxfe;
                    sbest_pos1=mean(p)*lamda*abs(gauss);
                    sbest_pos2=mean(p);  
                    if FUN(sbest_pos2)<FUN(sbest_pos1)
                        sbest_pos=sbest_pos2;global2=global2+1;
                    else
                        sbest_pos=sbest_pos1;global1=global1+1;
                    end
                    sbesty=compute_objectives(sbest_pos,D,problem_name);
                    FES=FES+1;
                    CE(FES,:)=[FES,sbesty];
                    if mod (FES,sn1)==0
                        cs1=FES/sn1;
                        gfs(1,cs1)=min(CE(1:FES,2));
                    end
                    hx=[hx;sbest_pos];   hf=[hf,sbesty];
                    if sbesty<bestever
                        gbpos=sbest_pos; 
                        globalcountsuc=globalcountsuc+1;   
                    end
                    [bestever,ib] = min([sbesty, bestever]); 
                end
                 
                if(localsearch == 1) % Local search
                    [~,idx]=sort(fitness); 
                    k=rand;
                    [mmin,id_min]=min(fitness);
                    if k<0.5
                        sbest_pos=p(id_min,:);
                    else
                        sbest_pos=mean(p)+(p(id_min,:)-mean(p))*rand;
                    end
                    sbesty=compute_objectives(sbest_pos,D,problem_name); %feval(fname,sbest_pos); %feval(fname,sbest_pos);
                    for i=1:ps
                        if idx(i)>=c
                            p(i,:)=sbest_pos;
                            fitness(i)=sbesty;
                        end
                    end
                    FES=FES+1;
                    CE(FES,:)=[FES,sbesty];
                    if mod (FES,sn1)==0
                        cs1=FES/sn1;
                        gfs(1,cs1)=min(CE(1:FES,2));
                    end
                    hx=[hx;sbest_pos];   hf=[hf,sbesty];
                    if sbesty<bestever
                        gbpos=sbest_pos; 
                        localcountsuc=localcountsuc+1;   
                    end
                    [bestever,ib] = min([sbesty, bestever]); 
                end
                
                if(globalsearch == 1)
                    globalcount=globalcount+1;
                end
                if(localsearch==1) 
                    localcount=localcount+1;
                end
                if(reversesearch==1) 
                    reversecount=reversecount+1;
                end 
                fprintf('globalcount: %d globalcountsuc: %d localcount: %d localcountsuc: %d reversecount: %d reversecountsuc: %d\n',globalcount ,globalcountsuc,localcount,localcountsuc,reversecount,reversecountsuc);

                % select the best ps sample points to form the population
                [~,idx]=sort(hf);   idx=idx(1:ps);
                p=hx(idx,:);        fitness=hf(idx);  
                pbest = p;
                pbestval = fitness;
                [gbestval,gbestid] = min(pbestval);
                gbest = pbest(gbestid,:);

               %% Part 2:  Dynamic adaptation strategy
                if(gbestval_old==gbestval)                        
                    localsearch=0;
                    r=rand;
                    if FES>=(ps+maxfe*0.1) && FES<maxfe*0.8
                        if reversecountsuc/reversecount<=0.1 && reversecount>maxfe*0.1
                            globalsearch=1;
                            reversesearch=0;
                        else
                            if r<=0.5
                                reversesearch=1;
                                globalsearch=0;
                            else
                                globalsearch=1;
                                reversesearch=0;
                            end
                        end
                    elseif FES>=maxfe*0.8
                        if r<=0.5
                            reversesearch=1;
                            globalsearch=0;
                        else
                            globalsearch=1;
                            reversesearch=0;
                        end
                    else
                        globalsearch=1;
                        reversesearch=0;
                    end
                else
                    if localcountsuc/localcount<0.1 && localcount>=maxfe*0.1
                        globalsearch=1;
                        reversesearch=0;
                        localsearch=0;
                    else
                        globalsearch=0;
                        reversesearch=0;
                        localsearch=1;
                    end
                end
                gbestval_old= gbestval;    
            end
            
           %% Phase 3: Competitive Swarm Optimizer 
            [fitness,rank] = sort(fitness, 'descend');
            p = p(rank,:);
            v = v(rank,:); 
            rlist=randperm(ps);
            rpairs=[rlist(1:ceil(ps/2)); rlist(floor(ps/2) + 1:ps)]';
            % calculate the center position
            center_ = ones(ceil(ps/2),1)*mean(p);
            % do pairwise competitions
            mask = (fitness(rpairs(:,1))' > fitness(rpairs(:,2))');
            losers = mask.*rpairs(:,1) + ~mask.*rpairs(:,2); 
            winners = ~mask.*rpairs(:,1) + mask.*rpairs(:,2);
            %random matrix 
            randco1 = rand(ceil(ps/2), D);
            randco2 = rand(ceil(ps/2), D);
            randco3 = rand(ceil(ps/2), D);
            phi=0.1;
            % losers learn from winners
            v(losers,:) = randco1.*v(losers,:) ...,
                        + randco2.*(p(winners,:) - p(losers,:)) ...,
                        + phi*randco3.*(center_ - p(losers,:));
            p(losers,:) = p(losers,:) + v(losers,:);
            if ifun==1
                lu = [-5.12 * ones(1, D); 5.12 * ones(1, D)];
            elseif ifun==2
                lu = [-2.048 * ones(1, D); 2.048 * ones(1, D)];
            elseif ifun==3
                lu = [-32.768 * ones(1, D); 32.768 * ones(1, D)];
            elseif ifun==4
                lu = [-600 * ones(1, D); 600 * ones(1, D)];
            elseif ifun==5
                lu = [-5.12 * ones(1, D); 5.12 * ones(1, D)];
%             elseif ifun==5
%                 lu = [-5 * ones(1, D); 5 * ones(1, D)];
%             elseif ifun==6
%                 lu = [-5 * ones(1, D); 5 * ones(1, D)];
            end
            % boundary control
            for i = 1:ceil(ps/2)
                p(losers(i),:) = max(p(losers(i),:), lu(1,:));
                p(losers(i),:) = min(p(losers(i),:), lu(2,:));
            end
            gen = gen + 1;  
            
           %% Phase 3: Training and Prediction of RBF Model
            if( updatemodel==1 ||firstupdate==1)
                firstupdate=0;
                updatemodel=0;
              if(globalsearch==1)
                trainx=hx;  trainf=hf;
              end
              if(reversesearch==1)                  
                [~,idx]=sort(hf);                                 
                idx=idx(1:ps);
                trainx=hx(idx,:);        trainf=hf(idx); 
              end
              if(localsearch==1)                 
                [~,idx]=sort(hf);
                idx=idx(1:ps);           
                trainx=hx(idx,:);        trainf=hf(idx); 
              end
                % radial basis function interpolation----(RBF-interpolation)
                flag='cubic';
                [lambda, gamma]=RBF(trainx,trainf',flag);
                FUN=@(x) RBF_eval(x,trainx,lambda,gamma,flag);
            end
            fitness=FUN(p);  
            fitness=fitness';
            pbest_all=[pbest;p];
            pbestval_all=[pbestval';fitness'];
            [~,id]=sort(pbestval_all);
            pbest_sort=pbest_all(id,:);
            pbestval_sort=pbestval_all(id);
            for i=1:ps
              pbest(i,:)=pbest_sort(i,:);
              pbestval(i)=pbestval_sort(i);
            end
            [gbestval,gbestid] = min(pbestval);
            gbest = pbest(gbestid,:);
            gbestrep= repmat(gbest,ps,1);
            p = pbest;    

        gsamp1(run,:)=gfs;
        end
        fprintf('Iteration: %d Fitness evaluation: %d Best fitness: %e\n', gen, FES, bestever);
    end 
end

